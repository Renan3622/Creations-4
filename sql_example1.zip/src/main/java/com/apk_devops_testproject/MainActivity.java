package com.apk_devops_testproject;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText _data1, _data2, _remove;
    DBHelper helper;
    private TextView _result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _data1 = findViewById(R.id.data1);
        _data2 = findViewById(R.id.data2);
        _remove = findViewById(R.id.KeyWord);
        _result = findViewById(R.id.theData);
        helper = new DBHelper(this);
    }

    //Set NEW Data1 and Data2 and insert it into Column 2 and Column 3
    public void newData(View view) {
        String user1 = _data1.getText().toString();
        String pass1 = _data2.getText().toString();
        if (user1.isEmpty() || pass1.isEmpty()) {
            Toaster.toastdata(getApplicationContext(), "Enter Both Data1 and Data2");
        } else {
            long id = helper.insertData(user1, pass1);
            if (id <= 0) {
                Toaster.toastdata(getApplicationContext(), "Error");
                _data1.setText("");
                _data2.setText("");
            } else {
                Toaster.toastdata(getApplicationContext(),  "Success");
                _data1.setText("");
                _data2.setText("");
            }
        }
    }

    //Read Data from DB and setText
    public void viewData(View view) {
        String data = helper.getData();
        _result.setText(data);
    }

    //Set new Data for Column 2 in DB and Update
    public void updateData1(View view) {
        String oldData = _data1.getText().toString();
        String newData = _data2.getText().toString();
        if (oldData.isEmpty() || newData.isEmpty()) {
            Toaster.toastdata(getApplicationContext(), "Enter Both Data1 and Data2");
        } else {
            int DBdata = helper.updateData1(oldData, newData);
            if (DBdata <= 0) {
                Toaster.toastdata(getApplicationContext(), "Error");
                _data1.setText("");
                _data2.setText("");
            } else {
                Toaster.toastdata(getApplicationContext(), "Success");
                _data1.setText("");
                _data2.setText("");
            }
        }

    }

    //Set new Data for Column 3 in DB and Update
    public void updateData2(View view) {
        String oldData = _data1.getText().toString();
        String newData = _data2.getText().toString();
        if (oldData.isEmpty() || newData.isEmpty()) {
            Toaster.toastdata(getApplicationContext(), "Enter Both Data1 and Data2");
        } else {
            int DBdata = helper.updateData2(oldData, newData);
            if (DBdata <= 0) {
                Toaster.toastdata(getApplicationContext(), "Error");
                _data1.setText("");
                _data2.setText("");
            } else {
                Toaster.toastdata(getApplicationContext(), "Success");
                _data1.setText("");
                _data2.setText("");
            }
        }

    }

    //Set removing data and remove from DB
    public void delete(View view) {
        String removingName = _remove.getText().toString();
        if (removingName.isEmpty()) {
            Toaster.toastdata(getApplicationContext(), "Enter Both Data1 and Data2");
        } else {
            int DBdata = helper._remove(removingName);
            if (DBdata <= 0) {
                Toaster.toastdata(getApplicationContext(), "Error");
                _remove.setText("");
            } else {
                Toaster.toastdata(this, "Success");
                _remove.setText("");
            }
        }
    }

    //Remove The data base
    public void clearFullDatabase(View view) {
        getApplicationContext().deleteDatabase("DBName");
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    //A class to Control Data BASE
    public static class DBHelper {
        theHelper helper;

        public DBHelper(Context context) {
            helper = new theHelper(context);
        }

        //Insert data into DB Table
        public long insertData(String name, String pass) {
            SQLiteDatabase dbb = helper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(theHelper.dbData1, name);
            contentValues.put(theHelper.dbData2, pass);
            return dbb.insert(theHelper.THE_TABLE, null, contentValues);
        }

        //Read the data in DB
        public String getData() {
            SQLiteDatabase db = helper.getWritableDatabase();
            String[] columns = {theHelper.UID, theHelper.dbData1, theHelper.dbData2};
            Cursor cursor = db.query(theHelper.THE_TABLE, columns, null, null, null, null, null);
            StringBuilder buffer = new StringBuilder();
            while (cursor.moveToNext()) {
                int cid = cursor.getInt(cursor.getColumnIndex(theHelper.UID));
                String name = cursor.getString(cursor.getColumnIndex(theHelper.dbData1));
                String password = cursor.getString(cursor.getColumnIndex(theHelper.dbData2));
                buffer.append(cid).append("   ").append(name).append("   ").append(password).append(" \n");
            }
            return buffer.toString();
        }

        //Remove the Data from DB by its ID
        public int _remove(String uname) {
            SQLiteDatabase db = helper.getWritableDatabase();
            String[] whereArgs = {uname};
            return db.delete(theHelper.THE_TABLE, theHelper.UID + " = ?", whereArgs);
        }

        //This updates Data1 value in DB
        public int updateData1(String oldName, String newName) {
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(theHelper.dbData1, newName);
            String[] whereArgs = {oldName};
            return db.update(theHelper.THE_TABLE, contentValues, theHelper.dbData1 + " = ?", whereArgs);
        }

        //This updates Data2 value in DB
        public int updateData2(String oldName, String newName) {
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(theHelper.dbData2, newName);
            String[] whereArgs = {oldName};
            return db.update(theHelper.THE_TABLE, contentValues, theHelper.dbData2 + " = ?", whereArgs);
        }

        static class theHelper extends SQLiteOpenHelper {
            private static final String DATABASE_NAME = "DBName";
            private static final String THE_TABLE = "table_name";
            private static final int DATABASE_Version = 1;
            private static final String UID = "_dbcolumn1";
            private static final String dbData1 = "_dbcolumn2";
            private static final String dbData2 = "_dbcolumn3";
            private static final String CREATE_TABLE = "CREATE TABLE " + THE_TABLE +
                    " (" + UID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + dbData1 + " VARCHAR(255) ," + dbData2 + " VARCHAR(225));";
            private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + THE_TABLE;
            private Context context;

            public theHelper(Context context) {
                super(context, DATABASE_NAME, null, DATABASE_Version);
                this.context = context;
            }

            public void onCreate(SQLiteDatabase db) {
                try {
                    db.execSQL(CREATE_TABLE);
                } catch (Exception e) {
                    Toaster.toastdata(context, "" + e);
                }
            }

            @Override
            public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
                try {
                    Toaster.toastdata(context, "OnUpgrade");
                    db.execSQL(DROP_TABLE);
                    onCreate(db);
                } catch (Exception e) {
                    Toaster.toastdata(context, "" + e);
                }
            }
        }
    }

    //A class to create Toast
    public static class Toaster {
        public static void toastdata(Context context, String toastdata) {
            Toast.makeText(context, toastdata, Toast.LENGTH_LONG).show();
        }
    }
}